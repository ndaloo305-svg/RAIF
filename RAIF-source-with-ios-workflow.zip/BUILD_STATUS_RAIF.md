# RAIF build status

This working copy is based on the supplied Nuvio Mobile source archive.

## Applied changes
- Renamed the Gradle root project to `RAIF`.
- Set Android application ID to `com.raif.app`.
- Set iOS app and shared framework bundle identifiers to `com.raif.app` and widget extension identifier to `com.raif.app.DownloadsWidgetExtension`.
- Removed the upstream Apple Developer Team ID so the project does not attempt to sign with another developer’s account.
- Set Android launcher name and iOS display name to `RAIF`.
- Updated the primary English and Arabic in-app brand labels to `RAIF`.
- Registered the `raif://` URL scheme and enabled RAIF deep-link parsing while retaining `nuvio://` compatibility.
- Changed default Trakt and Simkl redirect URI schemes to `raif://`.
- Kept upstream Kotlin/Swift package names and module names unchanged to avoid risky source-wide package refactors.

## Build validation
- The supplied ZIP was missing a valid end-of-central-directory record. Its file entries were recovered into a repaired source archive and passed `unzip -t` validation.
- Android build was attempted with `./gradlew :androidApp:assembleFullDebug`, but Gradle could not download its required distribution because this environment has no network access (`UnknownHostException: services.gradle.org`).
- iOS IPA cannot be built in this Linux environment; an IPA build requires macOS, Xcode, the Apple toolchain, and appropriate signing configuration.

## Branding completed
- Replaced upstream launcher and splash artwork with the RAIF monogram across iOS, Android, and shared Compose resources.
- Applied the RAIF midnight navy / electric cyan palette to launcher and launch backgrounds.
- Added `RAIF_BRAND.md` and `RAIF-brand-preview.png`.

## Remaining before a distributable release
- Build artifacts are not yet produced: this environment has no Xcode/macOS, and Gradle could not download its distribution because network access is unavailable.
- Set the Apple Developer Team/signing profile and configure any required service credentials.
- Build and test on Android and macOS/Xcode, then produce signed APK/AAB and IPA artifacts.
