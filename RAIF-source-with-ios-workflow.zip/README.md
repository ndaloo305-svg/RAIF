# RAIF Mobile

RAIF is an independent rebrand of the open-source Nuvio Mobile project. It keeps the original media library, add-on, subtitle, and playback foundations while using RAIF app identifiers and display name.

**Upstream project:** [Nuvio Mobile](https://github.com/NuvioMedia/NuvioMobile)

## Build from source

This repository is a customized source fork. The upstream MPVKit git submodule and the Apple engine framework are required for iOS builds; initialize the submodule and run `scripts/prepare-ios-dependencies.sh` on macOS before building.

### Android

Requires Android Studio, Android SDK, and the Gradle distribution specified by `gradle/wrapper/gradle-wrapper.properties`. The Android application ID is `com.raif.app`.

```bash
./gradlew :androidApp:assembleFullDebug
```

### iOS

Requires macOS and Xcode. The iOS bundle identifier is `com.raif.app`. The generated IPA is unsigned and can be signed for installation using an appropriate sideloading workflow.

```bash
./scripts/prepare-ios-dependencies.sh
./scripts/build-ios-ipa.sh
```

The shared app is built with Kotlin Multiplatform and Compose Multiplatform.

## License

This fork retains the upstream [GNU General Public License v3.0](./LICENSE) and attribution. RAIF is an independent rebrand and is not an official Nuvio release.
