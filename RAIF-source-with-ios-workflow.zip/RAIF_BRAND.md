# RAIF visual identity

- Primary name: RAIF
- Primary palette: Midnight Navy `#07111F`, Electric Cyan `#35D6E8`, Ice `#A6F5FF`, and soft white `#F1F7FC`.
- Mark: a geometric letter R integrated with a forward-play cue, representing the RAIF media experience.
- Primary app icon: Midnight Navy field with the Electric Cyan mark.
- Alternate icon choices retain the same RAIF mark in Arctic Blue, Emerald, Rose Gold, Copper, and Graphite accents.
- Launcher artwork, iOS AppIcon sets, Android adaptive icons, splash artwork, and in-app wordmarks use the same mark.
