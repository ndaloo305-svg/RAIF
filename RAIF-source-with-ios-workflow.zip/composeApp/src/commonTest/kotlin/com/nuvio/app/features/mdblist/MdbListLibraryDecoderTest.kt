package com.nuvio.app.features.mdblist

import com.nuvio.app.features.tracking.LibraryListPrivacy
import com.nuvio.app.features.tracking.TrackingLibraryTabKind
import com.nuvio.app.features.tracking.supportsContentType
import kotlinx.coroutines.test.runTest
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue
import kotlin.test.Test

class MdbListLibraryDecoderTest {
    @Test
    fun `only owned explicitly static movie and show lists become editable tabs`() {
        val rows = listOf(
            """{"id":1,"user_id":42,"type":"static","private":false,"name":"Movies","mediatype":"movie"}""",
            """{"ids":[2],"user_id":42,"type":"static","dynamic":false,"private":true,"name":"Mixed"}""",
            """{"id":3,"user_id":43,"type":"static","private":false,"name":"Another user"}""",
            """{"id":4,"type":"dynamic","dynamic":true,"name":"Rules"}""",
            """{"id":5,"type":"feed","dynamic":false,"name":"Feed"}""",
            """{"id":6,"type":"external","name":"External"}""",
            """{"id":7,"type":"official","name":"Official"}""",
            """{"id":8,"dynamic":false,"name":"Unknown"}""",
            """{"id":9,"type":"static","mediatype":"episode","name":"Episodes"}""",
            """{"id":10,"type":"static","dynamic":true,"name":"Inconsistent"}""",
            """{"id":11,"user_id":43,"type":"dynamic","dynamic":true,"name":"Another user's rules"}"""
        )
        val lists = decodeMdbListLibraryLists(rows.joinToString(",", "[", "]"), 42)
        assertEquals(listOf(1L, 2L), lists.map { it.id })
        assertEquals(setOf("movie"), lists[0].tab().supportedContentTypes)
        assertTrue(listOf("movie", "series", "show", "anime", "tv").all(lists[1].tab()::supportsContentType))
        assertFalse(lists[0].tab().supportsContentType("anime"))
        assertFalse(lists[1].tab().supportsContentType("episode"))
        assertEquals(LibraryListPrivacy.PUBLIC, lists[0].tab().privacy)
        assertEquals(LibraryListPrivacy.PRIVATE, lists[1].tab().privacy)
        assertEquals(listOf(4L, 10L), decodeMdbListDynamicLists(rows.joinToString(",", "[", "]"), 42).map { it.id })
    }

    @Test
    fun `owned dynamic lists become read-only tabs`() = runTest {
        val lists = decodeMdbListDynamicLists("""[
          {"id":12,"user_id":42,"type":"dynamic","dynamic":true,"private":false,"name":"Top Horror","mediatype":"movie",
           "description":"Rated above 7","last_updated_at":"2026-10-01T10:00:00Z"},
          {"ids":[13],"user_id":42,"dynamic":true,"name":"Mixed rules"},
          {"id":14,"user_id":42,"dynamic":true,"mediatype":"episode","name":"Episodes"}
        ]""", 42)
        assertEquals(listOf(
            MdbListDynamicList(12, "Top Horror", "Rated above 7", MdbListItemType.MOVIE, "2026-10-01T10:00:00Z"),
            MdbListDynamicList(13, "Mixed rules")
        ), lists)
        val tab = lists[0].tab()
        assertEquals("mdblist:dynamic:12", tab.key)
        assertEquals(TrackingLibraryTabKind.EXTERNAL, tab.kind)
        assertEquals(setOf("movie"), tab.supportedContentTypes)
        assertFalse(tab.isMembershipDestination)
        assertEquals("/lists/12/items", mdbListLibraryItemsPath(tab.key))
        expectMdbListFailure<MdbListDecodingException> {
            decodeMdbListDynamicLists("""[{"type":"dynamic","dynamic":true,"name":"Missing ID"}]""", 42)
        }
    }

    @Test
    fun `liked lists skip the account's own lists and page by offset`() = runTest {
        val page = decodeMdbListLikedLists("""{"lists":[
          {"id":79776,"user_id":41631,"user_name":"dinkysniff","name":"Best New Shows","description":"Rated over 60",
           "mediatype":"show","type":"static","dynamic":false,"last_updated_at":"2026-10-14T00:00:00Z","liked_at":"2026-10-14T10:00:00Z"},
          {"id":5,"user_id":42,"name":"Mine"},
          {"id":6,"user_id":43,"name":"Episodes","mediatype":"episode"}
        ],"pagination":{"page":1,"limit":3,"offset":0,"total":5,"has_more":true}}""", 42)
        assertEquals(listOf(MdbListLikedList(79776, "Best New Shows", "Rated over 60", MdbListItemType.SHOW, "2026-10-14T00:00:00Z")),
            page.items)
        assertEquals(3, page.nextOffset)
        val tab = page.items.single().tab()
        assertEquals("mdblist:liked:79776", tab.key)
        assertEquals(TrackingLibraryTabKind.EXTERNAL, tab.kind)
        assertTrue(tab.supportsContentType("series"))
        assertFalse(tab.supportsContentType("movie"))
        assertFalse(tab.isMembershipDestination)
        assertEquals("/lists/79776/items", mdbListLibraryItemsPath(tab.key))
        for (body in listOf("[]", """{"pagination":{}}""", """{"lists":[{"user_id":43,"name":"Missing ID"}]}""")) {
            expectMdbListFailure<MdbListDecodingException> { decodeMdbListLikedLists(body, 42) }
        }
    }

    @Test
    fun `sparse invalid or ambiguous static list responses cannot clear the cache`() = runTest {
        for (body in listOf("{}", "null", """[{"type":"static","private":true,"name":"Missing ID"}]""",
            """[{"id":7,"type":"static","name":"Missing privacy"}]""",
            """[{"ids":[7,8],"type":"static","private":true,"name":"Ambiguous"}]""")) {
            expectMdbListFailure<MdbListDecodingException> { decodeMdbListLibraryLists(body, 42) }
        }
        assertTrue(decodeMdbListLibraryLists("[]", 42).isEmpty())
    }

    @Test
    fun `list payloads merge nested and legacy external IDs with bundled metadata`() {
        val page = decodeMdbListLibraryPage("""{
          "movies":[{"id":278,"imdb_id":"tt0111161","ids":{"mdblist":"a0","tvdb":190,"imdb":null},
          "title":"Shawshank","release_year":1994,"poster":"/poster.jpg","description":"Plot","genres":["crime",{"name":"Drama"}],"rank":2}],
          "shows":[{"id":1396,"imdb_id":"tt0903747","mediatype":"show","title":"Breaking Bad","rank":1}],
          "episodes":[{}],"seasons":[{}],"pagination":{"next_cursor":"cursor-one","has_more":true}
        }""")
        assertEquals(2, page.items.size)
        val movie = page.items.first()
        assertEquals(MdbListIds("tt0111161", 278, 190, mdblist = "a0"), movie.media.ids)
        assertEquals("https://image.tmdb.org/t/p/w500/poster.jpg", movie.media.poster)
        assertEquals(1994, movie.media.year)
        assertEquals(listOf("crime", "Drama"), movie.genres)
        assertEquals("Plot", movie.description)
        assertEquals(MdbListItemType.SHOW, page.items.last().type)
        assertEquals("cursor-one", page.nextCursor)
    }

    @Test
    fun `watchlist timestamps use the provider local datetime`() {
        val page = decodeMdbListLibraryPage("""[{"id":1,"mediatype":"movie","watchlist_at":"2025-02-02 17:28:22.000000"}]""")
        assertEquals(mdbListTimestamp("2025-02-02 17:28:22.000000"), page.items.single().listedAt)
        assertEquals(mdbListTimestamp("2025-02-02T17:28:22Z"), page.items.single().listedAt)
    }

    @Test
    fun `unusual item dates do not discard the list`() {
        val page = decodeMdbListLibraryPage("""[
          {"id":1,"mediatype":"movie","listed_at":"2025-02-02"},
          {"id":2,"mediatype":"movie","listed_at":"not a date"}
        ]""")
        assertEquals(listOf(mdbListTimestamp("2025-02-02T00:00:00Z"), 0L), page.items.map { it.listedAt })
    }

    @Test
    fun `external lists decode their source and update time`() {
        val lists = decodeMdbListExternalLists("""[{"id":168202,"user_id":261168,"name":"IMDb Watchlist",
          "updated":"2026-09-29T12:32:29.000Z","items":1115,"source":"imdbwatchlist","private":false}]""")
        assertEquals(listOf(MdbListExternalList(168202, "IMDb Watchlist", "imdbwatchlist", updatedAt = "2026-09-29T12:32:29.000Z")), lists)
    }

    @Test
    fun `unified items retain their media namespaces and ignore episodes`() {
        for (body in listOf("""[{"id":1,"mediatype":"movie"},{"id":1,"mediatype":"show"},{"mediatype":"episode"}]""",
            """{"items":[{"id":1,"mediatype":"movie"},{"id":1,"mediatype":"show"}]}""")) {
            val page = decodeMdbListLibraryPage(body)
            assertEquals(listOf(MdbListItemType.MOVIE, MdbListItemType.SHOW), page.items.map { it.type })
            assertFalse(page.items[0].matches(page.items[1]))
        }
    }

    @Test
    fun `malformed pages and conflicting media types fail without inventing items`() = runTest {
        for (body in listOf("{}", "null", "[] junk", """{"movies":[{}]}""", """{"movies":[{"id":0}]}""",
            """[{"id":1}]""", """{"movies":[{"id":1,"mediatype":"show"}]}""", """{"movies":[{"id":1,"mediatype":"unknown"}]}""")) {
            expectMdbListFailure<MdbListDecodingException> { decodeMdbListLibraryPage(body) }
        }
    }

    @Test
    fun `pagination derives a next offset only when the server proves more items exist`() = runTest {
        val prefix = """{"movies":[],"pagination": """
        assertEquals(1000, decodeMdbListLibraryPage(prefix + """{"offset":0,"limit":1000,"total":1001}}""").nextOffset)
        assertEquals(null, decodeMdbListLibraryPage(prefix + """{"offset":0,"limit":1000,"total":1000}}""").nextOffset)
        expectMdbListFailure<MdbListDecodingException> {
            decodeMdbListLibraryPage(prefix + """{"has_more":true}}""")
        }
    }

    @Test
    fun `projection merges aliases across lists while preserving per-list order and movie show identity`() {
        val movie = MdbListLibraryItem(MdbListItemType.MOVIE, MdbListMedia(MdbListIds(tmdb = 1), "Movie"), rank = 4)
        val aliased = movie.copy(media = movie.media.copy(ids = MdbListIds("tt1", 1, tvdb = 3, trakt = 4, mdblist = "a1")), rank = 8)
        val show = movie.copy(type = MdbListItemType.SHOW, media = movie.media.copy(title = "Show"))
        val projection = MdbListLibraryProjection(MdbListLibrarySnapshot(itemsByList = mapOf(
            MDBLIST_WATCHLIST_KEY to listOf(movie, show), MDBLIST_TEST_LIST_KEY to listOf(aliased)
        )))
        assertEquals(2, projection.entries.size)
        val entry = projection.entries.first { it.type == "movie" }
        assertEquals("tt1", entry.id)
        assertEquals("a1", entry.trackingProviderItemId)
        assertEquals(mapOf(MDBLIST_WATCHLIST_KEY to 0, MDBLIST_TEST_LIST_KEY to 0), entry.listRanks)
        for (alias in listOf("tt1", "imdb:tt1", "tmdb:1", "tvdb:3", "trakt:4", "mdblist:a1")) {
            assertEquals(setOf(MDBLIST_WATCHLIST_KEY, MDBLIST_TEST_LIST_KEY), projection.membership(alias, "movie"))
            assertEquals(entry, projection.find(alias, "movie"))
            assertEquals(null, projection.find(alias, "episode"))
        }
        assertEquals(setOf(MDBLIST_WATCHLIST_KEY), projection.membership("tmdb:1", "anime"))
        assertTrue(projection.membership("tt1", "series").isEmpty())
        assertEquals("Show", projection.find("tmdb:1", "anime")?.name)
    }
}
